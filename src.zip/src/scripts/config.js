const CONFIG = {
  BASE_URL: "https://story-api.dicoding.dev/v1",
  CACHE_NAME: "StoryApp-v1",
  VAPID_PUBLIC_KEY:
    "BN7-r0Svv7CzhLW7kI6y5dj8agI9llJVthVW3pvL1KX4Cxz1DPiPdownRuT9cf3xLHjdHYuMHYA8cOydb35gSgZo",
};

export default CONFIG;
