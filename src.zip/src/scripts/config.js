const CONFIG = {
  BASE_URL: "https://story-api.dicoding.dev/v1",
  CACHE_NAME: "StoryApp-v1",
};

export default CONFIG;
